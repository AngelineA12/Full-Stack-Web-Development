let buttonPressCounts = {
  'A0': 0,
  'A1': 0,
  'A2': 0,
  'A4': 0,
  'A6': 0,
  'AWide': 0,
  'ANoBall': 0,
  'AWickets': 0,
  'B0': 0,
  'B1': 0,
  'B2': 0,
  'B4': 0,
  'B6': 0,
  'BWide': 0,
  'BNoBall': 0,
  'BWickets': 0,
};

let isMatchOver = false;
let isTeamATurn = true;
// Retrieve the team names from localStorage
var team1 = localStorage.getItem('team1');
var team2 = localStorage.getItem('team2');

// Display the team names
document.getElementById("teamAName").textContent = team1;
document.getElementById("teamBName").textContent = team2;

let consecutiveZeros = 0; // Added for tracking consecutive zero runs


function updateScore(team, runs) {
  if (isMatchOver) {
    alert("The match is already over. Further updates are not allowed.");
    return;
  }

  if ((team === 'B' && isTeamATurn) || (team === 'A' && !isTeamATurn)) {
    alert("It's not your turn. Wait for the other team to finish.");
    return;
  }

  const buttonKey = `${team}${runs}`;

  buttonPressCounts[buttonKey]++;

  const runsElement = document.getElementById(`runs${team}`);
  const wicketsElement = document.getElementById(`wickets${team}`);
  const oversElement = document.getElementById(`overs${team}`);
  const ballsLeftElement = document.getElementById(`ballsLeft${team}`);
  const maidenOversElement = document.getElementById(`maidenOvers${team}`);

  let runsValue = parseInt(runsElement.textContent, 10);
  let wicketsValue = parseInt(wicketsElement.textContent, 10);
  let oversValue = parseFloat(oversElement.textContent);
  let ballsLeftValue = parseInt(ballsLeftElement.textContent, 10);
  let maidenOversValue = parseInt(maidenOversElement.textContent, 10);

  if (runs === 'Wide') {
    runsValue += 1;
  } else if (runs === 'NoBall') {
    runsValue += 1; // Increment runs for No Ball
  } else {
    runsValue += runs;
    ballsLeftValue -= 1;

    // Update overs when balls reach 6
    if (ballsLeftValue % 6 === 0) {
      oversValue += 1;
      consecutiveZeros = 0; // Reset consecutive zeros for the next over
      oversElement.textContent = oversValue.toFixed(1);
    }
  }

  runsElement.textContent = runsValue;
  ballsLeftElement.textContent = ballsLeftValue;
  maidenOversElement.textContent = maidenOversValue;

  // Inside the else block where runs are updated
  if (runs === 0) {
    consecutiveZeros++;

    if (consecutiveZeros === 6) {
      // Increment maiden overs when there are 6 consecutive zero runs
      maidenOversValue += 1;
      consecutiveZeros = 0; // Reset consecutive zeros for the next over
    }
  } else {
    consecutiveZeros = 0; // Reset consecutive zeros if runs are not zero
  }

  if (runs === 'Wickets') {
    wicketsValue += 1;
    buttonPressCounts[`${team}Wickets`]++;
  }

  wicketsElement.textContent = wicketsValue;

  if (ballsLeftValue === 0) {
    alert(`Team`+team1+` turn is over. They have no balls left.`);

    if (team === 'A') {
      isTeamATurn = false;
      alert(`It's `+team2+`'s turn now. Click OK to start`+team2+`'s innings.`);
    } else {
      compareScores();
      isMatchOver = true;
      disableButtons();
      viewSummaryDetails();
    }
  }
}

function updateWickets(team) {
  if (isMatchOver) {
    alert("The match is already over. Further updates are not allowed.");
    return;
  }

  if ((team === 'B' && isTeamATurn) || (team === 'A' && !isTeamATurn)) {
    alert("It's not your turn. Wait for the other team to finish.");
    return;
  }

  var currentWickets = document.getElementById(`wickets${team}`).innerHTML;
  currentWickets = parseInt(currentWickets) + 1;

  buttonPressCounts[`${team}Wickets`]++;

  document.getElementById(`wickets${team}`).innerHTML = currentWickets;

  if (currentWickets >= 10) {
    alert(`Team ${team}'s turn is over. They have lost all wickets.`);

    if (team === 'A') {
      isTeamATurn = false;
      alert(`It's`+team2+`'s turn now. Click OK to start`+team2+`'s innings.`);
    } else {
      compareScores();
      isMatchOver = true;
      disableButtons();
      viewSummaryDetails();
    }
  }
}

function compareScores() {
  const runsTeamA = parseInt(document.getElementById('runsA').textContent, 10);
  const runsTeamB = parseInt(document.getElementById('runsB').textContent, 10);

  if (runsTeamA > runsTeamB) {
    alert(team1+` wins!`);
  } else if (runsTeamA < runsTeamB) {
    alert(team2+` wins!`);
  } else {
    alert("It's a tie!");
  }
}

function disableButtons() {
  const buttons = document.getElementsByTagName('button');
  for (const button of buttons) {
    button.disabled = true;
  }
}

function viewSummaryDetails() {
  // Create a table element
  const table = document.createElement('table');

  // Create a header row
  const headerRow = table.insertRow(0);
  const headerCell1 = headerRow.insertCell(0);
  headerCell1.textContent = 'Summary';

  // Labels for the summary cells
  const summaryLabels = ['1s', '2s', '4s', '6s', 'Wide', 'No Ball', 'Wickets', 'Maiden Overs'];

  // Populate the table with data for Team A
  let cellNumA = 1;
  for (const label of summaryLabels) {
    const cell = headerRow.insertCell(cellNumA++);
    cell.textContent = label;
  }

  // Create a new row for counts of Team A
  const countRowBatting = table.insertRow(1);
  const countCellBatting1 = countRowBatting.insertCell(0);
  countCellBatting1.textContent = team1;

  // Populate the count row with data for Team A
  cellNumA = 1;
  for (const buttonKey in buttonPressCounts) {
    if (buttonKey.startsWith('A')) {
      const countCellBatting1 = countRowBatting.insertCell(cellNumA++);
      countCellBatting1.textContent = buttonPressCounts[buttonKey];
    }
  }

  // Create a new row for counts of the selected bowling team
  const countRowBowling = table.insertRow(2);
  const countCellBowling1 = countRowBowling.insertCell(0);
  countCellBowling1.textContent = team2;

  // Populate the count row with data for Team B
  let cellNumB = 1;
  for (const buttonKey in buttonPressCounts) {
    if (buttonKey.startsWith('B')) {
      const countCellBowling1 = countRowBowling.insertCell(cellNumB++);
      countCellBowling1.textContent = buttonPressCounts[buttonKey];
    }
  }

  // Display the table in the modal content
  const summaryContent = document.getElementById('summaryContent');
  summaryContent.innerHTML = ''; // Clear previous content
  summaryContent.appendChild(table);

  // Display the modal
  document.getElementById('myModal').style.display = 'block';
}

function closeModal() {
  document.getElementById('myModal').style.display = 'none';
}
