<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page 2</title>
</head>
<body>
    <center>
        <h1>Student information using Get and Post</h1>

  
    <?php
            if ($_SERVER["REQUEST_METHOD"] == "GET") {
                echo "Using GET method:<br>";
                echo "Roll No: " . $_GET['rollNo'] . "<br>";
            echo "Name: " . $_GET['name'] . "<br>";
            echo "Class: " . $_GET['class'] . "<br>";
            echo "Section: " . $_GET['section'] . "<br>";
            echo "Email: " . $_GET['email'] . "<br>";
            echo "Phone Number: " . $_GET['phoneNumber'] . "<br>";
            echo "City: " . $_GET['city'] . "<br>";
                
            } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
                echo "Using POST method:<br>";
                echo "Roll No: " . $_POST['rollNo'] . "<br>";
            echo "Name: " . $_POST['name'] . "<br>";
            echo "Class: " . $_POST['class'] . "<br>";
            echo "Section: " . $_POST['section'] . "<br>";
            echo "Email: " . $_POST['email'] . "<br>";
            echo "Phone Number: " . $_POST['phoneNumber'] . "<br>";
            echo "City: " . $_POST['city'] . "<br>";
            }
        ?>
 </center>
</body>
</html>