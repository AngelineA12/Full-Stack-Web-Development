<!DOCTYPE html>
<html>
<head>
    <title>Page 1</title>
    <style>
        h1{
            color: #fff;
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
        }
        body {
            font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    margin: 20px;
    background-image: url("https://i.pinimg.com/originals/5c/b0/25/5cb025d5c32c501e9d2c9b482a5d38a1.jpg");
    background-repeat: no-repeat;
    background-size:cover;
    }

form {
    margin-bottom: 20px;
    border: 1px solid #ccc;
    padding: 50px;
    width: 300px;
    background: linear-gradient(to bottom,#444b4f,#010103);
    border-radius:90px;
    color: #fff;
  
}

label {
    display: block;
    margin-bottom: 5px;
    color: #fff;
}

input[type="text"] {
    width: calc(100% - 12px);
    padding:10px;
    margin-bottom: 10px;
    border-radius:90px;
    color: #fff;
    width: 200px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

input[type="submit"] {
    padding: 8px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    cursor: pointer;
    border-radius:90px;
    color: #fff;
    animation: glowing 1300ms infinite;
    font-family:cursive;
    
}

input[type="submit"]:hover {
    background-color: #0056b3;
    border-radius:90px;
    color: #fff;
    font-size:20px;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
}
@keyframes glowing {
    0% {
      background-color:  #060c24;
      box-shadow: 0 0 5px #ffffff;
    }
    50% {
      background-color: #060c24;
      box-shadow: 0 0 20px #ffffff;
    }
    100% {
      background-color: #060c24;
      box-shadow: 0 0 5px #ffffff;
    }
  }


.display-data {
    border: 1px solid #ccc;
    padding: 20px;
    width: 300px;
}


    </style>
</head>
<body>
    <center>
        <h1>Student information using Get and Post</h1>
    <form id="studentForm" action="Lab10page2.php" method="get">
        <label for="rollNo">Roll No:</label>
        <input type="text" name="rollNo"><br>
        
        <label for="name">Name:</label>
        <input type="text" name="name"><br>
        
        <label for="class">Class:</label>
        <input type="text" name="class"><br>
        
        <label for="section">Section:</label>
        <input type="text" name="section"><br>
        
        <label for="email">Email:</label>
        <input type="text" name="email"><br>
        
        <label for="phoneNumber">Phone Number:</label>
        <input type="text" name="phoneNumber"><br>
        
        <label for="city">City:</label>
        <input type="text" name="city"><br><br>
        
        <input type="submit" value="Submit (GET)" onclick="setFormGetMethod()">
        <input type="submit" value="Submit (POST)" onclick="setFormPostMethod()">
    </form>
    
   

</center>
    <script>
        function setFormGetMethod() {
            document.getElementById('studentForm').setAttribute('method', 'get');
        }

        function setFormPostMethod() {
            document.getElementById('studentForm').setAttribute('method', 'post');
        }
    </script>
   
</body>
</html>