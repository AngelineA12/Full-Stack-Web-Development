<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Result</title>
    <style>
        /* Your CSS styles for process.php */
        body {
            font-family: 'Arial', sans-serif;
            margin: 20px;
            background-image:linear-gradient(to right, #c04848 0%, #480048 100%);
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-right-width:9px;
 border-top-left-radius:50px;
 border-top-right-radius:50px;
 border-bottom-left-radius:50px;
 border-bottom-right-radius:50px;
 box-shadow:0px 0px 35px 0px #f1c40f;
 margin-right:auto !important;
 padding:30px;
 transition: transform 0.3s ease-in-out;
        }

    .container:hover{ transform: scale(1.05);}
        h2 {
            color: #4caf50;
            font-family:Georgia, 'Times New Roman', Times, serif;
 letter-spacing:6.6px;
 word-spacing:6.7px;
        }

        p {
            margin-bottom: 8px;
            color: #333;
            font-family:'TimesNewRoman','Times New Roman',Times,Baskerville,Georgia,serif;
            font-size:20px;
        }

        .error {
            color: red;
            font-weight: bold;
            margin-top: 16px;
        }

        /* Add media query for better responsiveness */
        @media (max-width: 600px) {
            .container {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<br><br><br><br>
<div class="container">
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = htmlspecialchars($_POST["name"]);
        $email = htmlspecialchars($_POST["email"]);
        $password = htmlspecialchars($_POST["password"]);
        $confirmPassword = htmlspecialchars($_POST["confirmPassword"]);
        $city = htmlspecialchars($_POST["city"]);

        // Validate data on the server side
        $errors = array();

        if (!preg_match("/^[A-Za-z ]+$/", $name)) {
            $errors[] = "Invalid name. Use only alphabets and spaces.";
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email address.";
        }

        if (strlen($password) < 8) {
            $errors[] = "Password should be at least eight characters long.";
        }

        if ($password !== $confirmPassword) {
            $errors[] = "Passwords do not match.";
        }

        // Display success or error messages
        if (empty($errors)) {
            // Process data and calculate discount
            $discount = ($city == "Bangalore") ? 20 : 10;

            // Display success message along with the submitted information
            echo "<h2>Registration Successful!</h2>";
            echo "<p>Name: $name</p>";
            echo "<p>Email: $email</p>";
            echo "<p>City: $city</p>";
            echo "<p>Discount: $discount%</p>";
        } else {
            // Display error messages
            echo "<h2>Error:</h2>";
            foreach ($errors as $error) {
                echo "<p class='error'>$error</p>";
            }
        }
    } else {
        echo "Error: Invalid request.";
    }
    ?>
</div>

</body>
</html>
