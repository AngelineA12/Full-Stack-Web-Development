<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $sql = "INSERT INTO users (name, email) VALUES ('$name', '$email')";
    $result = $conn->query($sql);

    if ($result) {
        echo 'User created successfully.';
    } else {
        echo 'Error: ' . $conn->error;
    }
}

$conn->close();
?>
