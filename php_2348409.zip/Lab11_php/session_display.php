<?php
session_start();

// Check if session variable exists
if (isset($_SESSION['stored_data']) && !empty($_SESSION['stored_data'])) {
    $storedData = $_SESSION['stored_data'];

    echo "<h2>Stored Data:</h2>";
    echo "<ul>";
    foreach ($storedData as $data) {
        echo "<li>$data</li>";
    }
    echo "</ul>";
} else {
    echo "No data stored in session.";
}
?>
