<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $deleteName = $_POST['delete_name'];

    $deleteSql = "DELETE FROM users WHERE name = '$deleteName'";
    $deleteResult = $conn->query($deleteSql);

    if ($deleteResult) {
        echo 'User deleted successfully.';
    } else {
        echo 'Error deleting user: ' . $conn->error;
    }
}

$conn->close();
?>
