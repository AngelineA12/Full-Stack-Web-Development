<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookie Demo</title>
</head>
<body>
    <h1>Cookie Demo</h1>

    <form method="post" action="">
        <label for="cookie_value">Enter a value:</label>
        <input type="text" id="cookie_value" name="cookie_value" required>
        <button type="submit" name="submit">Set Cookie</button>
    </form>
    <?php
        // Check if the form is submitted
        if(isset($_POST['submit'])) {
            // Get the value from the form
            $cookieValue = $_POST['cookie_value'];

            // Set the cookie with a 24-hour expiration time
            setcookie('demo_cookie', $cookieValue, time() + (24 * 60 * 60));

            echo '<p>Cookie has been set successfully!</p>';

           // Add a link to display.php
           echo '<p><a href="cookie_display.php">Click here to view the stored cookie value</a></p>';
        }
    ?>
    
</body>
</html>
