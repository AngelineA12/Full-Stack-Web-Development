<?php
include 'config.php';

$sql = "SELECT * FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<ul>';
    while ($row = $result->fetch_assoc()) {
        echo '<li>' . $row['name'] . ' - ' . $row['email'] . '</li>';
    }
    echo '</ul>';
} else {
    echo 'No users found.';
}

$conn->close();
?>
