<?php
$filePath = "C:\wamp64\www\Lab11_php\sample.txt";

if (file_exists($filePath)) {
    unlink($filePath);
    echo "File deleted successfully.";
} else {
    echo "File not found.";
}
?>
