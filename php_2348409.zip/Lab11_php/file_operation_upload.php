<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $targetDir = "C:\wamp64\www\Lab11_php";
    $targetFile = $targetDir . basename($_FILES["file"]["name"]);
    
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
        echo "The file " . htmlspecialchars(basename($_FILES["file"]["name"])) . " has been uploaded.";

        // Read and display the content of the uploaded file
        $fileContent = file_get_contents($targetFile);
        echo "<h3>File Content:</h3>";
        echo "<pre>$fileContent</pre>";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>
