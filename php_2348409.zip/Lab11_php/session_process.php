<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['data'])) {
        $data = $_POST['data'];

        // Store data in session variable
        $_SESSION['stored_data'][] = $data;

        echo "Data successfully stored in session.";
    } else {
        echo "Error: Data not provided.";
    }
} else {
    // Redirect to index if accessed directly
    header('Location: index.html');
    exit;
}
?>
