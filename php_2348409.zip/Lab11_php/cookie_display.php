<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Cookie Value</title>
</head>
<body>
    <h1>Display Cookie Value</h1>

    <?php
        // Check if the cookie is set
        if(isset($_COOKIE['demo_cookie'])) {
            $cookieValue = $_COOKIE['demo_cookie'];
            echo '<p>The stored cookie value is: ' . $cookieValue . '</p>';
        } else {
            echo '<p>No cookie value set yet.</p>';
        }
    ?>
</body>
</html>
